<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'restro' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'Vn.*n1/@LNrgnV;&pGuOR@:>[pNW~E8jkNr<YMW.&P32`6Ft<~L[pzON5COS{ka.' );
define( 'SECURE_AUTH_KEY',  '!4(qH${kDwr^ne=UAe2p/,##PpVxe-gg*.U2a[h#y5oy$Upa!$a=[Sk6~#:(nt3$' );
define( 'LOGGED_IN_KEY',    'Z8ggbDG|>9l$l*/8[xv*6uLZ52rj&Y?t0:I6Q6yuV7%wf:Kx1Rw#$vD(Ov#HO.m6' );
define( 'NONCE_KEY',        'z= OX!FO9pes^p<$Kz`Sby6cAy&hE`O/Oh--q>Pf=f^p|j/&KB)XDHI_+Ngg,0fa' );
define( 'AUTH_SALT',        ':wN6`-zlRMZRzwxY4]`TQAvIKDY<3@^E#>KI9)#zV/w/+d|TlW$Gy_f$TIL>aU>=' );
define( 'SECURE_AUTH_SALT', 'G_Ai!4c<]D5(M82OYS@C9LfgRK5xL1JW#2]1-mZ!C>tX2g/tF#TxMN-#mo|5}?f!' );
define( 'LOGGED_IN_SALT',   '<v%Ta(SK.=X{e5WCW lY;jvHtQYW=lU&1>OM3Wp}|I~8:e33Qc>Cxtq9U.kDt*f1' );
define( 'NONCE_SALT',       '3bOHiaP) ?lHZ2Y<0eP0K_%_%PtOr-X/ 9L?wTnJ5tWd&9GALY&}x|Z@<SBP_qn/' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
