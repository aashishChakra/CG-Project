<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'lasa_bhutu' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'eX){Xzn~^,z4U0(%l{jk4nc.o*z(%nIa@G.rM<84QnVzj:-$^$62KpBwV8,VNtIB' );
define( 'SECURE_AUTH_KEY',  'KiOh!r/?;J=h {j1~Ay!XGhXa=P#m^;bQK0o])U1A%Y4M$a eAtIL7?N6.L*cw;/' );
define( 'LOGGED_IN_KEY',    'o0~Z0[l<|8YnEo@0 }v!N/&a{klYT]Y*bEVb(K}ECn~O,jtQsn^cIZsO:kVoi3Fi' );
define( 'NONCE_KEY',        'O9kw-?K>=cKX:l<qUnowry2*g #5,9j^!]&`lh$zh2JxL&s/e`)_em:Wq@J|_w;=' );
define( 'AUTH_SALT',        '[*rduRYJBKg;u=M@1K(!=_tuhD@9XGxN|l`{b<}uK.{x>_io>(aob?%^^Ifd+m*,' );
define( 'SECURE_AUTH_SALT', '>f}W9Wu0KkNNq)Hk~KiW!nq+O2C+9__8vZ|o2n&bojdonp]93iPr^}rU2|-@YJ0#' );
define( 'LOGGED_IN_SALT',   '~XWY}$[U=3?8eI[_`Mh,ZbUCz; AIA-oS4+i-FPg^7Q,<4mXlOu)}A_:l)7|JOAi' );
define( 'NONCE_SALT',       ';pU MJQ9N`=.@O79^m~Ig_~BK1;Jykg&.+#VQQ{O;jm*r+Qar bzo|8ajh>S*{=7' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
